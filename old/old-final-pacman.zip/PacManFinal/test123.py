for i in range(5):
    jano='sdasd'
    print('shit')
print(jano)
